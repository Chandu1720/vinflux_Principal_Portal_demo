import React, { createContext, useContext, useState } from 'react';
import type {
  Product,
  Portfolio,
  ProductType,
  ProductTemplate,
  AttributeDefinition,
  TrackingRuleTemplate,
  ValidationRule,
  UomPackagingDefault,
  InventoryPolicyDefaults,
  Principal,
  CurrentUser
} from '../types/product.ts';
import type { Branch } from '../types/branch.ts';
import type { Warehouse } from '../types/warehouse.ts';

import {
  initialProducts,
  initialPortfolios,
  initialProductTypes,
  initialProductTemplates,
  initialAttributeTemplates,
  initialTrackingRuleTemplates,
  initialValidationRules,
  initialUomPackagingDefaults,
  initialInventoryPolicyDefaults,
  initialPrincipals,
  initialCurrentUser
} from '../data/productMasterData.ts';

import { initialBranches } from '../data/branchData.ts';
import { initialWarehouses } from '../data/warehouseData.ts';

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'danger' | 'warning' | 'info';
}

interface AppContextType {
  // Current user & active principal
  currentUser: CurrentUser;
  setCurrentUser: React.Dispatch<React.SetStateAction<CurrentUser>>;
  principals: Principal[];
  activePrincipal: Principal;
  setActivePrincipal: (p: Principal) => void;

  // Toast
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'danger' | 'warning' | 'info') => void;
  removeToast: (id: string) => void;

  // Products
  products: Product[];
  selectedProductId: string;
  setSelectedProductId: (id: string) => void;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  duplicateProduct: (id: string) => Product;
  retireProduct: (id: string) => void;
  bulkUpdateProductStatus: (ids: string[], status: Product['lifecycleStatus']) => void;

  // Product configurations
  portfolios: Portfolio[];
  productTypes: ProductType[];
  productTemplates: ProductTemplate[];
  attributeTemplates: Record<string, AttributeDefinition[]>;
  trackingRuleTemplates: TrackingRuleTemplate[];
  validationRules: ValidationRule[];
  uomPackagingDefaults: UomPackagingDefault[];
  inventoryPolicyDefaults: InventoryPolicyDefaults;
  addPortfolio: (portfolio: Portfolio) => void;
  addProductType: (type: ProductType) => void;

  // Branch Master
  branches: Branch[];
  addBranch: (branch: Branch) => { success: boolean; message: string };
  updateBranch: (id: string, updates: Partial<Branch>) => { success: boolean; message: string };
  toggleBranchStatus: (id: string) => void;

  // Warehouse Master
  warehouses: Warehouse[];
  addWarehouse: (warehouse: Warehouse) => { success: boolean; message: string };
  updateWarehouse: (id: string, updates: Partial<Warehouse>) => { success: boolean; message: string };
  toggleWarehouseStatus: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<CurrentUser>(initialCurrentUser);
  const [principals] = useState<Principal[]>(initialPrincipals);
  const [activePrincipal, setActivePrincipal] = useState<Principal>(initialPrincipals[0]);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (message: string, type: 'success' | 'danger' | 'warning' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Products State
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [selectedProductId, setSelectedProductId] = useState<string>("PRD-EVOCON-001");

  // Configuration items
  const [portfolios, setPortfolios] = useState<Portfolio[]>(initialPortfolios);
  const [productTypes, setProductTypes] = useState<ProductType[]>(initialProductTypes);
  const [productTemplates] = useState<ProductTemplate[]>(initialProductTemplates);
  const [attributeTemplates] = useState<Record<string, AttributeDefinition[]>>(initialAttributeTemplates);
  const [trackingRuleTemplates] = useState<TrackingRuleTemplate[]>(initialTrackingRuleTemplates);
  const [validationRules] = useState<ValidationRule[]>(initialValidationRules);
  const [uomPackagingDefaults] = useState<UomPackagingDefault[]>(initialUomPackagingDefaults);
  const [inventoryPolicyDefaults] = useState<InventoryPolicyDefaults>(initialInventoryPolicyDefaults);

  // Branches & Warehouses State
  const [branches, setBranches] = useState<Branch[]>(initialBranches);
  const [warehouses, setWarehouses] = useState<Warehouse[]>(initialWarehouses);

  // PRODUCT ACTIONS
  const addProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`Product "${newProduct.name}" created successfully.`, 'success');
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((prod) =>
        prod.id === id ? { ...prod, ...updates, updatedAt: new Date().toISOString().substring(0, 10) } : prod
      )
    );
    showToast(`Product ${id} updated successfully.`, 'info');
  };

  const duplicateProduct = (id: string): Product => {
    const original = products.find((p) => p.id === id);
    if (!original) throw new Error("Product not found");

    const newCode = `${original.code}-COPY-${Math.floor(100 + Math.random() * 900)}`;
    const cloned: Product = {
      ...original,
      id: `prod-${Date.now()}`,
      code: newCode,
      name: `${original.name} (Copy)`,
      lifecycleStatus: 'Draft',
      changeHistory: [
        {
          field: 'lifecycleStatus',
          prevValue: original.lifecycleStatus,
          newValue: 'Draft',
          changedBy: currentUser.name,
          changedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          reason: `Cloned from ${original.code}`
        }
      ],
      updatedAt: new Date().toISOString().substring(0, 10),
      updatedBy: currentUser.name
    };

    setProducts((prev) => [cloned, ...prev]);
    showToast(`Product duplicated as "${cloned.name}".`, 'success');
    return cloned;
  };

  const retireProduct = (id: string) => {
    setProducts((prev) =>
      prev.map((prod) =>
        prod.id === id ? { ...prod, lifecycleStatus: 'Retired', updatedAt: new Date().toISOString().substring(0, 10) } : prod
      )
    );
    showToast(`Product ${id} retired.`, 'warning');
  };

  const bulkUpdateProductStatus = (ids: string[], status: Product['lifecycleStatus']) => {
    setProducts((prev) =>
      prev.map((p) => (ids.includes(p.id) ? { ...p, lifecycleStatus: status } : p))
    );
    showToast(`Bulk updated ${ids.length} product(s) to "${status}".`, 'info');
  };

  const addPortfolio = (portfolio: Portfolio) => {
    setPortfolios((prev) => [...prev, portfolio]);
    showToast(`Added Portfolio "${portfolio.name}".`, 'success');
  };

  const addProductType = (type: ProductType) => {
    setProductTypes((prev) => [...prev, type]);
    showToast(`Added Product Type "${type.name}".`, 'success');
  };

  // BRANCH MASTER ACTIONS
  const addBranch = (branch: Branch): { success: boolean; message: string } => {
    // Validate unique code
    const isDuplicate = branches.some((b) => b.code.trim().toUpperCase() === branch.code.trim().toUpperCase());
    if (isDuplicate) {
      const msg = `Branch code "${branch.code}" already exists. Branch codes must be unique.`;
      showToast(msg, 'danger');
      return { success: false, message: msg };
    }

    setBranches((prev) => [...prev, branch]);
    showToast(`Branch "${branch.name}" (${branch.code}) created successfully.`, 'success');
    return { success: true, message: 'Branch created successfully.' };
  };

  const updateBranch = (id: string, updates: Partial<Branch>): { success: boolean; message: string } => {
    if (updates.code) {
      const isDuplicate = branches.some(
        (b) => b.id !== id && b.code.trim().toUpperCase() === updates.code!.trim().toUpperCase()
      );
      if (isDuplicate) {
        const msg = `Branch code "${updates.code}" already exists for another branch.`;
        showToast(msg, 'danger');
        return { success: false, message: msg };
      }
    }

    setBranches((prev) =>
      prev.map((b) => (b.id === id ? { ...b, ...updates, updatedAt: new Date().toISOString().substring(0, 10) } : b))
    );

    // If branch name changed, also update denormalized branchName in warehouses
    if (updates.name) {
      setWarehouses((prev) =>
        prev.map((w) => (w.branchId === id ? { ...w, branchName: updates.name } : w))
      );
    }

    showToast(`Branch updated successfully.`, 'success');
    return { success: true, message: 'Branch updated successfully.' };
  };

  const toggleBranchStatus = (id: string) => {
    setBranches((prev) =>
      prev.map((b) => {
        if (b.id === id) {
          const next = b.status === 'Active' ? 'Inactive' : 'Active';
          if (next === 'Inactive') {
            showToast(
              `Branch "${b.name}" set to Inactive. It can no longer be selected for new assignments.`,
              'warning'
            );
          } else {
            showToast(`Branch "${b.name}" activated.`, 'success');
          }
          return { ...b, status: next, updatedAt: new Date().toISOString().substring(0, 10) };
        }
        return b;
      })
    );
  };

  // WAREHOUSE MASTER ACTIONS
  const addWarehouse = (warehouse: Warehouse): { success: boolean; message: string } => {
    // 1. Validate branch exists and is Active
    const branch = branches.find((b) => b.id === warehouse.branchId);
    if (!branch) {
      const msg = `Selected branch ID "${warehouse.branchId}" does not exist.`;
      showToast(msg, 'danger');
      return { success: false, message: msg };
    }
    if (branch.status !== 'Active') {
      const msg = `Cannot create warehouse under inactive branch "${branch.name}". Only active branches may have new warehouses.`;
      showToast(msg, 'danger');
      return { success: false, message: msg };
    }

    // 2. Validate unique code
    const isDuplicate = warehouses.some((w) => w.code.trim().toUpperCase() === warehouse.code.trim().toUpperCase());
    if (isDuplicate) {
      const msg = `Warehouse code "${warehouse.code}" already exists. Warehouse codes must be unique.`;
      showToast(msg, 'danger');
      return { success: false, message: msg };
    }

    const warehouseWithBranch: Warehouse = {
      ...warehouse,
      branchName: branch.name
    };

    setWarehouses((prev) => [...prev, warehouseWithBranch]);

    // Update branch active warehouses count
    setBranches((prev) =>
      prev.map((b) =>
        b.id === warehouse.branchId
          ? { ...b, activeWarehousesCount: (b.activeWarehousesCount || 0) + (warehouse.status === 'Active' ? 1 : 0) }
          : b
      )
    );

    showToast(`Warehouse "${warehouse.name}" (${warehouse.code}) created under branch "${branch.name}".`, 'success');
    return { success: true, message: 'Warehouse created successfully.' };
  };

  const updateWarehouse = (id: string, updates: Partial<Warehouse>): { success: boolean; message: string } => {
    if (updates.code) {
      const isDuplicate = warehouses.some(
        (w) => w.id !== id && w.code.trim().toUpperCase() === updates.code!.trim().toUpperCase()
      );
      if (isDuplicate) {
        const msg = `Warehouse code "${updates.code}" already exists for another warehouse.`;
        showToast(msg, 'danger');
        return { success: false, message: msg };
      }
    }

    if (updates.branchId) {
      const branch = branches.find((b) => b.id === updates.branchId);
      if (!branch) {
        return { success: false, message: 'Invalid branch ID.' };
      }
      updates.branchName = branch.name;
    }

    setWarehouses((prev) =>
      prev.map((w) => (w.id === id ? { ...w, ...updates, updatedAt: new Date().toISOString().substring(0, 10) } : w))
    );

    showToast(`Warehouse updated successfully.`, 'success');
    return { success: true, message: 'Warehouse updated successfully.' };
  };

  const toggleWarehouseStatus = (id: string) => {
    setWarehouses((prev) =>
      prev.map((w) => {
        if (w.id === id) {
          const next = w.status === 'Active' ? 'Inactive' : 'Active';
          if (next === 'Inactive') {
            showToast(
              `Warehouse "${w.name}" set to Inactive. It can no longer be selected as a supply source.`,
              'warning'
            );
          } else {
            showToast(`Warehouse "${w.name}" activated.`, 'success');
          }
          return { ...w, status: next, updatedAt: new Date().toISOString().substring(0, 10) };
        }
        return w;
      })
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        principals,
        activePrincipal,
        setActivePrincipal,
        toasts,
        showToast,
        removeToast,
        products,
        selectedProductId,
        setSelectedProductId,
        addProduct,
        updateProduct,
        duplicateProduct,
        retireProduct,
        bulkUpdateProductStatus,
        portfolios,
        productTypes,
        productTemplates,
        attributeTemplates,
        trackingRuleTemplates,
        validationRules,
        uomPackagingDefaults,
        inventoryPolicyDefaults,
        addPortfolio,
        addProductType,
        branches,
        addBranch,
        updateBranch,
        toggleBranchStatus,
        warehouses,
        addWarehouse,
        updateWarehouse,
        toggleWarehouseStatus
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
